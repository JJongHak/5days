package kr.ac.yonsei.a5days.adapter;

public class Adapter {
}
